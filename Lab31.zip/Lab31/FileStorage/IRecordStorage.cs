namespace FileStorage;

public interface IRecordStorage
{
    DataRecord[] Read();
    void Write(DataRecord[] records);
}
