namespace FileStorage;

/// <summary>Один запис файлу: тип, ім'я об'єкта та пари «атрибут: значення».</summary>
public class DataRecord
{
    public DataRecord(string typeName, string objectName, string[] keys, string[] values)
    {
        TypeName = typeName;
        ObjectName = objectName;
        Keys = keys;
        Values = values;
    }

    public string TypeName { get; }
    public string ObjectName { get; }
    public string[] Keys { get; }
    public string[] Values { get; }

    public string Get(string key, string defaultValue = null)
    {
        for (int i = 0; i < Keys.Length; i++)
            if (Keys[i] == key) return Values[i];
        return defaultValue;
    }
}
