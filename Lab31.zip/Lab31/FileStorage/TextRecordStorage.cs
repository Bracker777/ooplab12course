using System.Text;
using System.Text.RegularExpressions;

namespace FileStorage;

/// <summary>
/// Єдиний файл для всіх типів. Формат:
/// Тип Назва
/// { "атрибут1": "значення1",
///   "атрибут2": "значення2"};
/// </summary>
public class TextRecordStorage : IRecordStorage
{
    private static readonly Regex Attribute =
        new("^\\s*\\{?\\s*\"(?<k>[^\"]+)\"\\s*:\\s*\"(?<v>[^\"]*)\"\\s*,?\\s*$");

    private readonly string _path;

    public TextRecordStorage(string path) => _path = path;

    public DataRecord[] Read()
    {
        if (!File.Exists(_path)) return new DataRecord[0];

        string text;
        using (var reader = new StreamReader(_path, Encoding.UTF8))
            text = reader.ReadToEnd();

        string[] blocks = text.Split("};", StringSplitOptions.RemoveEmptyEntries);
        int count = 0;
        foreach (string b in blocks)
            if (b.Trim().Length > 0) count++;

        var result = new DataRecord[count];
        int index = 0;
        foreach (string block in blocks)
        {
            if (block.Trim().Length == 0) continue;

            string[] lines = block.Trim().Split('\n');
            string[] header = lines[0].Trim().Split(' ');
            if (header.Length != 2) throw new FormatException("Некоректний заголовок запису: " + lines[0]);

            int n = lines.Length - 1;
            var keys = new string[n];
            var values = new string[n];
            for (int j = 0; j < n; j++)
            {
                Match m = Attribute.Match(lines[j + 1].TrimEnd('\r'));
                if (!m.Success) throw new FormatException("Некоректний атрибут: " + lines[j + 1]);
                keys[j] = m.Groups["k"].Value;
                values[j] = m.Groups["v"].Value;
            }
            result[index++] = new DataRecord(header[0], header[1], keys, values);
        }
        return result;
    }

    public void Write(DataRecord[] records)
    {
        using var writer = new StreamWriter(_path, false, new UTF8Encoding(false));
        foreach (DataRecord r in records)
        {
            writer.WriteLine(r.TypeName + " " + r.ObjectName);
            for (int j = 0; j < r.Keys.Length; j++)
            {
                string prefix = j == 0 ? "{ " : "  ";
                string suffix = j == r.Keys.Length - 1 ? "};" : ",";
                writer.WriteLine($"{prefix}\"{r.Keys[j]}\": \"{r.Values[j]}\"{suffix}");
            }
        }
    }
}
