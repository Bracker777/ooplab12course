# Діаграма класів. Лабораторна робота 3.1, варіант 5

```mermaid
---
title: Діаграма класів (варіант 5)
---
classDiagram
    direction TB

    %% ---------- Предметна область ----------
    class Person {
        <<абстрактний>>
        +FirstName : ім'я
        +LastName : прізвище
        +Id : унікальний ідентифікатор
    }
    class Student {
        +Course : курс
        +StudentId : студентський квиток
        +RecordBookNumber : залікова книжка
        +AverageGrade : середній бал
        +Country : країна
        +LivesInUkraine : проживає в Україні
    }
    class McdonaldsWorker {
        +EmployeeId : табельний номер
    }
    class Manager {
        +EmployeeId : табельний номер
        +Department : відділ
    }
    class IStudier {
        <<інтерфейс>>
        +Study() : навчатися
    }
    class ITeacher {
        <<інтерфейс>>
        +Teach() : навчати
    }
    class IDriver {
        <<інтерфейс>>
        +Drive() : керувати авто
    }
    class IChessPlayer {
        <<інтерфейс>>
        +PlayChess() : грати в шахи
    }
    Person <|-- Student : наслідування
    Person <|-- McdonaldsWorker : наслідування
    Person <|-- Manager : наслідування
    IStudier <|.. Student : реалізує
    IStudier <|.. McdonaldsWorker : реалізує
    IDriver <|.. McdonaldsWorker : реалізує
    ITeacher <|.. Manager : реалізує
    IChessPlayer <|.. Student : реалізує
    IChessPlayer <|.. Manager : реалізує

    %% ---------- Проєкт FileStorage ----------
    class IRecordStorage {
        <<інтерфейс>>
        +Read() : читати записи
        +Write() : записати записи
    }
    class TextRecordStorage {
        файл-джерело даних
    }
    class DataRecord {
        +TypeName : тип
        +ObjectName : назва об'єкта
        +Keys : атрибути
        +Values : значення
    }
    IRecordStorage <|.. TextRecordStorage : реалізує
    IRecordStorage ..> DataRecord : використовує

    %% ---------- Відображення Person <-> запис файлу ----------
    class IPersonMapper {
        <<інтерфейс>>
        +TypeName
        +Fields : опис полів
        +CanMap()
        +ToRecord() : сутність у запис
        +FromRecord() : запис у сутність
    }
    class PersonMapper~T~ {
        <<абстрактний>>
    }
    class StudentMapper
    class McdonaldsWorkerMapper
    class ManagerMapper
    class PersonConverter {
        вибирає mapper за типом
    }
    IPersonMapper <|.. PersonMapper : реалізує
    PersonMapper <|-- StudentMapper : наслідування
    PersonMapper <|-- McdonaldsWorkerMapper : наслідування
    PersonMapper <|-- ManagerMapper : наслідування
    PersonConverter o-- IPersonMapper : агрегація
    IPersonMapper ..> Person : використовує
    IPersonMapper ..> DataRecord : використовує

    %% ---------- Сервіси та інтерфейс користувача ----------
    class IPersonRepository {
        <<інтерфейс>>
        +GetAll() +Add() +Remove()
        +FindByLastName() +FindById()
    }
    class PersonRepository
    class IStudentReport {
        <<інтерфейс>>
        +ThirdYearFromUkraine() : студенти 3-го курсу з України
    }
    class StudentReport
    class ConsoleMenu {
        ввід-вивід на консоль
    }
    IPersonRepository <|.. PersonRepository : реалізує
    IStudentReport <|.. StudentReport : реалізує
    PersonRepository --> IRecordStorage : залежить від
    PersonRepository --> PersonConverter : залежить від
    StudentReport --> IPersonRepository : залежить від
    ConsoleMenu --> IPersonRepository : залежить від
    ConsoleMenu --> IStudentReport : залежить від
    ConsoleMenu --> PersonConverter : залежить від
```
