using System.Text;
using FileStorage;
using LabApp.Mapping;
using LabApp.Services;
using LabApp.UI;

Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;

// Composition root: усі залежності збираються тут (IoC).
IRecordStorage storage = new TextRecordStorage(Path.Combine(AppContext.BaseDirectory, "data.txt"));
var converter = new PersonConverter(new IPersonMapper[]
{
    new StudentMapper(),
    new McdonaldsWorkerMapper(),
    new ManagerMapper()
});
IPersonRepository repository = new PersonRepository(storage, converter);
IStudentReport report = new StudentReport(repository);

new ConsoleMenu(repository, report, converter).Run();
