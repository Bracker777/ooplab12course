using FileStorage;
using LabApp.Domain;

namespace LabApp.Mapping;

public class ManagerMapper : PersonMapper<Manager>
{
    public override string TypeName => "Manager";

    public override FieldSpec[] Fields { get; } =
    {
        new("firstname", "Ім'я", Rules.Name),
        new("lastname", "Прізвище", Rules.Name),
        new("employeeId", "Табельний номер (MC12345)", Rules.EmployeeId),
        new("department", "Відділ", Rules.Words, "General")
    };

    protected override string[] ToValues(Manager m) => new[] { m.FirstName, m.LastName, m.EmployeeId, m.Department };

    protected override Manager Create(DataRecord r) =>
        new(r.Get("firstname"), r.Get("lastname"), r.Get("employeeId"), r.Get("department", "General"));
}
