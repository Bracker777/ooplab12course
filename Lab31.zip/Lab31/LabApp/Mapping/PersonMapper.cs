using FileStorage;
using LabApp.Domain;

namespace LabApp.Mapping;

public abstract class PersonMapper<T> : IPersonMapper where T : Person
{
    public abstract string TypeName { get; }
    public abstract FieldSpec[] Fields { get; }

    protected abstract string[] ToValues(T person);
    protected abstract T Create(DataRecord record);

    public bool CanMap(Person person) => person.GetType() == typeof(T);

    public DataRecord ToRecord(Person person) =>
        new(TypeName, person.FirstName + person.LastName,
            Array.ConvertAll(Fields, f => f.Key), ToValues((T)person));

    public Person FromRecord(DataRecord record) => Create(record);
}
