using FileStorage;
using LabApp.Domain;

namespace LabApp.Mapping;

public interface IPersonMapper
{
    string TypeName { get; }
    FieldSpec[] Fields { get; }
    bool CanMap(Person person);
    DataRecord ToRecord(Person person);
    Person FromRecord(DataRecord record);
}
