using System.Text.RegularExpressions;

namespace LabApp.Mapping;

/// <summary>Опис атрибута: ключ у файлі, підказка, правило перевірки, значення за умовчанням (null = обов'язковий).</summary>
public class FieldSpec
{
    public FieldSpec(string key, string prompt, Regex rule, string defaultValue = null)
    {
        Key = key;
        Prompt = prompt;
        Rule = rule;
        DefaultValue = defaultValue;
    }

    public string Key { get; }
    public string Prompt { get; }
    public Regex Rule { get; }
    public string DefaultValue { get; }
}
