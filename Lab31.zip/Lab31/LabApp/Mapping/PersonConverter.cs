using FileStorage;
using LabApp.Domain;

namespace LabApp.Mapping;

/// <summary>Вибирає потрібний mapper за типом; нові типи додаються лише новим mapper-ом.</summary>
public class PersonConverter
{
    public PersonConverter(IPersonMapper[] mappers) => Mappers = mappers;

    public IPersonMapper[] Mappers { get; }

    public DataRecord ToRecord(Person person) =>
        (Array.Find(Mappers, m => m.CanMap(person))
         ?? throw new InvalidOperationException("Невідомий тип: " + person.GetType().Name)).ToRecord(person);

    public Person FromRecord(DataRecord record) =>
        (Array.Find(Mappers, m => m.TypeName == record.TypeName)
         ?? throw new FormatException("Невідомий тип у файлі: " + record.TypeName)).FromRecord(record);
}
