using System.Globalization;
using FileStorage;
using LabApp.Domain;

namespace LabApp.Mapping;

public class StudentMapper : PersonMapper<Student>
{
    public override string TypeName => "Student";

    public override FieldSpec[] Fields { get; } =
    {
        new("firstname", "Ім'я", Rules.Name),
        new("lastname", "Прізвище", Rules.Name),
        new("course", "Курс (1-6)", Rules.Course),
        new("studentId", "Студентський квиток (напр. KB123456)", Rules.StudentId),
        new("recordBook", "Номер залікової книжки (8 цифр)", Rules.RecordBook),
        new("averageGrade", "Середній бал (0-100)", Rules.Grade, "0"),
        new("country", "Країна", Rules.Words, "Ukraine")
    };

    protected override string[] ToValues(Student s) => new[]
    {
        s.FirstName, s.LastName, s.Course.ToString(), s.StudentId, s.RecordBookNumber,
        s.AverageGrade.ToString(CultureInfo.InvariantCulture), s.Country
    };

    protected override Student Create(DataRecord r) => new(
        r.Get("firstname"), r.Get("lastname"), int.Parse(r.Get("course") ?? ""),
        r.Get("studentId"), r.Get("recordBook"),
        double.Parse(r.Get("averageGrade", "0"), CultureInfo.InvariantCulture),
        r.Get("country", "Ukraine"));
}
