using FileStorage;
using LabApp.Domain;

namespace LabApp.Mapping;

public class McdonaldsWorkerMapper : PersonMapper<McdonaldsWorker>
{
    public override string TypeName => "McdonaldsWorker";

    public override FieldSpec[] Fields { get; } =
    {
        new("firstname", "Ім'я", Rules.Name),
        new("lastname", "Прізвище", Rules.Name),
        new("employeeId", "Табельний номер (MC12345)", Rules.EmployeeId)
    };

    protected override string[] ToValues(McdonaldsWorker w) => new[] { w.FirstName, w.LastName, w.EmployeeId };

    protected override McdonaldsWorker Create(DataRecord r) =>
        new(r.Get("firstname"), r.Get("lastname"), r.Get("employeeId"));
}
