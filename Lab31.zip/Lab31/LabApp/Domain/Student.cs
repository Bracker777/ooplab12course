using System.Globalization;

namespace LabApp.Domain;

public class Student : Person, IStudier, IChessPlayer
{
    public Student(string firstName, string lastName, int course, string studentId,
                   string recordBookNumber, double averageGrade = 0, string country = "Ukraine")
        : base(firstName, lastName)
    {
        Course = int.Parse(Rules.Require(course.ToString(), Rules.Course, nameof(Course)));
        StudentId = Rules.Require(studentId, Rules.StudentId, nameof(StudentId));
        RecordBookNumber = Rules.Require(recordBookNumber, Rules.RecordBook, nameof(RecordBookNumber));
        AverageGrade = double.Parse(
            Rules.Require(averageGrade.ToString(CultureInfo.InvariantCulture), Rules.Grade, nameof(AverageGrade)),
            CultureInfo.InvariantCulture);
        Country = Rules.Require(country, Rules.Words, nameof(Country));
    }

    public int Course { get; }
    public string StudentId { get; }
    public string RecordBookNumber { get; }
    public double AverageGrade { get; }
    public string Country { get; }

    public int StudyHours { get; private set; }
    public int GamesPlayed { get; private set; }

    public override string Id => StudentId;

    public bool LivesInUkraine =>
        Country.Equals("Ukraine", StringComparison.OrdinalIgnoreCase) ||
        Country.Equals("Україна", StringComparison.OrdinalIgnoreCase);

    public void Study() => StudyHours++;      // навчання у ВНЗ
    public void PlayChess() => GamesPlayed++;
}
