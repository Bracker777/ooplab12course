namespace LabApp.Domain;

public class Manager : Person, ITeacher, IChessPlayer
{
    public Manager(string firstName, string lastName, string employeeId, string department = "General")
        : base(firstName, lastName)
    {
        EmployeeId = Rules.Require(employeeId, Rules.EmployeeId, nameof(EmployeeId));
        Department = Rules.Require(department, Rules.Words, nameof(Department));
    }

    public string EmployeeId { get; }
    public string Department { get; }
    public int LessonsGiven { get; private set; }
    public int GamesPlayed { get; private set; }

    public override string Id => EmployeeId;

    public void Teach() => LessonsGiven++;    // навчання персоналу
    public void PlayChess() => GamesPlayed++;
}
