namespace LabApp.Domain;

public abstract class Person
{
    protected Person(string firstName, string lastName)
    {
        FirstName = Rules.Require(firstName, Rules.Name, nameof(FirstName));
        LastName = Rules.Require(lastName, Rules.Name, nameof(LastName));
    }

    public string FirstName { get; }
    public string LastName { get; }

    /// <summary>Унікальний ідентифікатор (студентський квиток, табельний номер тощо).</summary>
    public abstract string Id { get; }
}
