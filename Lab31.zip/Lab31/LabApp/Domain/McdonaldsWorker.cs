namespace LabApp.Domain;

public class McdonaldsWorker : Person, IStudier, IDriver
{
    public McdonaldsWorker(string firstName, string lastName, string employeeId)
        : base(firstName, lastName)
    {
        EmployeeId = Rules.Require(employeeId, Rules.EmployeeId, nameof(EmployeeId));
    }

    public string EmployeeId { get; }
    public int StudyHours { get; private set; }
    public int Trips { get; private set; }

    public override string Id => EmployeeId;

    public void Study() => StudyHours++;      // самонавчання
    public void Drive() => Trips++;           // доставка замовлень
}
