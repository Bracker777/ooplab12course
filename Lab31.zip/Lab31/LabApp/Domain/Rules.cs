using System.Text.RegularExpressions;

namespace LabApp.Domain;

/// <summary>Єдине місце регулярних виразів для перевірки даних.</summary>
public static class Rules
{
    public static readonly Regex Name = new(@"^[A-Za-zА-Яа-яІіЇїЄєҐґ'’-]{1,30}$");
    public static readonly Regex Words = new(@"^[A-Za-zА-Яа-яІіЇїЄєҐґ'’ -]{2,40}$");
    public static readonly Regex Course = new(@"^[1-6]$");
    public static readonly Regex StudentId = new(@"^[A-Z]{2}\d{6}$");
    public static readonly Regex RecordBook = new(@"^\d{8}$");
    public static readonly Regex Grade = new(@"^(100|\d{1,2}(\.\d{1,2})?)$");
    public static readonly Regex EmployeeId = new(@"^MC\d{5}$");

    public static string Require(string value, Regex rule, string field)
    {
        if (value is null || !rule.IsMatch(value))
            throw new ArgumentException($"Некоректне значення поля {field}: '{value}'");
        return value;
    }
}
