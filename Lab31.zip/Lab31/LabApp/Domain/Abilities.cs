namespace LabApp.Domain;

public interface IStudier { int StudyHours { get; } void Study(); }
public interface ITeacher { int LessonsGiven { get; } void Teach(); }
public interface IDriver { int Trips { get; } void Drive(); }
public interface IChessPlayer { int GamesPlayed { get; } void PlayChess(); }
