using System.Text.RegularExpressions;
using FileStorage;
using LabApp.Domain;
using LabApp.Mapping;
using LabApp.Services;

namespace LabApp.UI;

/// <summary>Увесь ввід-вивід на консоль.</summary>
public class ConsoleMenu
{
    private readonly IPersonRepository _repository;
    private readonly IStudentReport _report;
    private readonly PersonConverter _converter;

    public ConsoleMenu(IPersonRepository repository, IStudentReport report, PersonConverter converter)
    {
        _repository = repository;
        _report = report;
        _converter = converter;
    }

    public void Run()
    {
        while (true)
        {
            Console.WriteLine("\n1 - Додати особу\n2 - Показати всіх\n3 - Видалити за ідентифікатором" +
                              "\n4 - Пошук за прізвищем\n5 - Пошук за ідентифікатором" +
                              "\n6 - Студенти 3-го курсу з України\n7 - Дії (Study/Teach/Drive/PlayChess)\n0 - Вихід");
            try
            {
                switch (Console.ReadLine()?.Trim())
                {
                    case "1": Add(); break;
                    case "2": PrintAll(_repository.GetAll()); break;
                    case "3": Console.WriteLine(_repository.Remove(ReadLine("Ідентифікатор")) ? "Видалено." : "Не знайдено."); break;
                    case "4": PrintAll(_repository.FindByLastName(ReadValid("Прізвище", Rules.Name))); break;
                    case "5": PrintFound(_repository.FindById(ReadLine("Ідентифікатор"))); break;
                    case "6": PrintReport(); break;
                    case "7": Demonstrate(); break;
                    case "0": return;
                }
            }
            catch (Exception ex) when (ex is ArgumentException or InvalidOperationException or FormatException)
            {
                Console.WriteLine("Помилка: " + ex.Message);
            }
        }
    }

    private void Add()
    {
        IPersonMapper[] mappers = _converter.Mappers;
        for (int i = 0; i < mappers.Length; i++)
            Console.WriteLine($"{i + 1} - {mappers[i].TypeName}");
        int choice = int.Parse(ReadValid("Тип", new Regex($"^[1-{mappers.Length}]$")));
        IPersonMapper mapper = mappers[choice - 1];

        var keys = new string[mapper.Fields.Length];
        var values = new string[mapper.Fields.Length];
        for (int i = 0; i < keys.Length; i++)
        {
            keys[i] = mapper.Fields[i].Key;
            values[i] = ReadField(mapper.Fields[i]);
        }

        var record = new DataRecord(mapper.TypeName, values[0] + values[1], keys, values);
        _repository.Add(_converter.FromRecord(record));
        Console.WriteLine("Додано.");
    }

    private void PrintReport()
    {
        Student[] students = _report.ThirdYearFromUkraine();
        Console.WriteLine($"Кількість студентів 3-го курсу, що проживають в Україні: {students.Length}");
        PrintAll(students);
    }

    private void Demonstrate()
    {
        foreach (Person p in _repository.GetAll())
        {
            if (p is IStudier s) { s.Study(); Console.WriteLine($"{p.LastName}: Study, годин = {s.StudyHours}"); }
            if (p is ITeacher t) { t.Teach(); Console.WriteLine($"{p.LastName}: Teach, занять = {t.LessonsGiven}"); }
            if (p is IDriver d) { d.Drive(); Console.WriteLine($"{p.LastName}: Drive, поїздок = {d.Trips}"); }
            if (p is IChessPlayer c) { c.PlayChess(); Console.WriteLine($"{p.LastName}: PlayChess, партій = {c.GamesPlayed}"); }
        }
    }

    private void PrintAll(Person[] people)
    {
        if (people.Length == 0) Console.WriteLine("Нічого не знайдено.");
        foreach (Person p in people) Print(p);
    }

    private void PrintFound(Person person)
    {
        if (person is null) Console.WriteLine("Нічого не знайдено.");
        else Print(person);
    }

    private void Print(Person person)
    {
        DataRecord record = _converter.ToRecord(person);
        Console.WriteLine($"{record.TypeName} {record.ObjectName}");
        for (int i = 0; i < record.Keys.Length; i++)
            Console.WriteLine($"  {record.Keys[i]}: {record.Values[i]}");
    }

    private static string ReadField(FieldSpec field)
    {
        while (true)
        {
            Console.Write(field.DefaultValue is null
                ? $"{field.Prompt}: "
                : $"{field.Prompt} (Enter — {field.DefaultValue}): ");
            string input = Console.ReadLine()?.Trim() ?? "";
            if (input.Length == 0 && field.DefaultValue is not null) return field.DefaultValue;
            if (field.Rule.IsMatch(input)) return input;
            Console.WriteLine("Невірний формат, повторіть.");
        }
    }

    private static string ReadValid(string prompt, Regex rule) =>
        ReadField(new FieldSpec("", prompt, rule));

    private static string ReadLine(string prompt)
    {
        Console.Write(prompt + ": ");
        return Console.ReadLine()?.Trim() ?? "";
    }
}
