namespace LabApp.Services;

/// <summary>Фільтрація масивів (колекції не використовуються).</summary>
public static class ArrayFilter
{
    public static T[] Where<T>(T[] source, Func<T, bool> predicate)
    {
        int count = 0;
        foreach (T item in source)
            if (predicate(item)) count++;

        var result = new T[count];
        int i = 0;
        foreach (T item in source)
            if (predicate(item)) result[i++] = item;
        return result;
    }
}
