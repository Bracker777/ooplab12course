using LabApp.Domain;

namespace LabApp.Services;

public interface IStudentReport
{
    /// <summary>Студенти 3-го курсу, які проживають в Україні (дані читаються з файлу).</summary>
    Student[] ThirdYearFromUkraine();
}

public class StudentReport : IStudentReport
{
    private readonly IPersonRepository _repository;

    public StudentReport(IPersonRepository repository) => _repository = repository;

    public Student[] ThirdYearFromUkraine()
    {
        Person[] found = ArrayFilter.Where(_repository.GetAll(),
            p => p is Student s && s.Course == 3 && s.LivesInUkraine);
        return Array.ConvertAll(found, p => (Student)p);
    }
}
