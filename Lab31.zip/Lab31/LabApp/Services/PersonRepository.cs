using FileStorage;
using LabApp.Domain;
using LabApp.Mapping;

namespace LabApp.Services;

public class PersonRepository : IPersonRepository
{
    private readonly IRecordStorage _storage;
    private readonly PersonConverter _converter;

    public PersonRepository(IRecordStorage storage, PersonConverter converter)
    {
        _storage = storage;
        _converter = converter;
    }

    public Person[] GetAll()
    {
        DataRecord[] records = _storage.Read();
        var result = new Person[records.Length];
        for (int i = 0; i < records.Length; i++)
            result[i] = _converter.FromRecord(records[i]);
        return result;
    }

    public void Add(Person person)
    {
        Person[] all = GetAll();
        if (Array.Exists(all, p => p.Id == person.Id))
            throw new InvalidOperationException("Особа з таким ідентифікатором вже існує.");
        Array.Resize(ref all, all.Length + 1);
        all[^1] = person;
        Save(all);
    }

    public bool Remove(string id)
    {
        Person[] all = GetAll();
        Person[] rest = ArrayFilter.Where(all, p => p.Id != id);
        if (rest.Length == all.Length) return false;
        Save(rest);
        return true;
    }

    public Person[] FindByLastName(string lastName) =>
        ArrayFilter.Where(GetAll(), p => p.LastName.Equals(lastName, StringComparison.OrdinalIgnoreCase));

    public Person FindById(string id) =>
        Array.Find(GetAll(), p => p.Id == id);

    private void Save(Person[] people)
    {
        var records = new DataRecord[people.Length];
        for (int i = 0; i < people.Length; i++)
            records[i] = _converter.ToRecord(people[i]);
        _storage.Write(records);
    }
}
