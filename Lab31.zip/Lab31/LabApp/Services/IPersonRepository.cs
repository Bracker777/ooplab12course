using LabApp.Domain;

namespace LabApp.Services;

public interface IPersonRepository
{
    Person[] GetAll();
    void Add(Person person);
    bool Remove(string id);
    Person[] FindByLastName(string lastName);
    Person FindById(string id);
}
